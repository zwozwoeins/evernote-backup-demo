#!/bin/bash
# Evernote-Exporter starten (Linux). Aufruf: ./evernote-exporter.sh [ORDNER]
# Beim ersten Start wird evernote-backup einmalig eingerichtet (Internet nötig, ca. 1 Minute).
cd "$(dirname "$0")/app" || exit 1
ENV="${XDG_DATA_HOME:-$HOME/.local/share}/evernote-exporter/python"
fail() { echo; echo "✗ $1"; shift; for s in "$@"; do echo "  – $s"; done; echo; read -rp "Enter drücken zum Beenden. " _; exit 1; }
command -v python3 >/dev/null 2>&1 || fail "Python 3 fehlt." "Ubuntu/Debian: sudo apt install python3 python3-venv" "Fedora: sudo dnf install python3" "Dann den Exporter neu starten."
python3 -c "import sys; sys.exit(sys.version_info < (3, 10))" || fail "Python ist zu alt (mindestens 3.10 nötig)." "Bitte Python aktualisieren, dann neu starten."
if [ ! -x "$ENV/bin/evernote-backup" ]; then
  echo "Der Exporter wird einmalig eingerichtet …"
  rm -rf "$ENV"; mkdir -p "$(dirname "$ENV")"
  python3 -m venv "$ENV" >/dev/null 2>&1 || { rm -rf "$ENV"; fail "Python-Umgebung fehlt." "Ubuntu/Debian: sudo apt install python3-venv" "Dann den Exporter neu starten."; }
  "$ENV/bin/pip" install -q "evernote-backup==1.14.0" || { rm -rf "$ENV"; fail "Die Einrichtung hat nicht geklappt." "Internet prüfen." "Dann den Exporter neu starten."; }
fi
exec "$ENV/bin/python3" exporter.py "$@"
