#!/bin/bash
# Evernote-Exporter starten (Linux und Mac). Aufruf: ./evernote-exporter.sh [ORDNER]
# Beim ersten Start wird evernote-backup einmalig eingerichtet (Internet nötig, ca. 1 Minute).
cd "$(dirname "$0")/app" || exit 1

if [ "$(uname -s)" = "Darwin" ]; then
  ENV="$HOME/Library/Application Support/Evernote-Exporter/python"
  PY_HINT="Python kostenlos von python.org laden und installieren (die Seite öffnet sich gleich)."
else
  ENV="${XDG_DATA_HOME:-$HOME/.local/share}/evernote-exporter/python"
  PY_HINT="Ubuntu/Debian: sudo apt install python3 python3-venv – Fedora: sudo dnf install python3"
fi

fail() {
  echo; echo "✗ $1"; shift
  for s in "$@"; do echo "  – $s"; done
  echo; read -r -p "Enter drücken zum Beenden. " _
  exit 1
}

open_python_org() {
  [ "$(uname -s)" = "Darwin" ] && open "https://www.python.org/downloads/macos/"
}

find_python() {
  for p in python3.13 python3.12 python3.11 python3.10 python3; do
    if command -v "$p" >/dev/null 2>&1 && "$p" -c "import sys; sys.exit(sys.version_info < (3, 10))" 2>/dev/null; then
      echo "$p"; return 0
    fi
  done
  return 1
}

setup_env() {
  echo "Der Exporter wird einmalig eingerichtet …"
  rm -rf "$ENV"; mkdir -p "$(dirname "$ENV")"
  "$PY" -m venv "$ENV" >/dev/null 2>&1 || { rm -rf "$ENV"; fail "Python-Umgebung fehlt." "$PY_HINT" "Dann den Exporter neu starten."; }
  "$ENV/bin/pip" install -q "evernote-backup==1.14.0" || { rm -rf "$ENV"; fail "Die Einrichtung hat nicht geklappt." "Internet prüfen." "Dann den Exporter neu starten."; }
}

if [ ! -x "$ENV/bin/evernote-backup" ]; then
  PY=$(find_python) || { open_python_org; fail "Python 3.10 oder neuer fehlt." "$PY_HINT" "Dann den Exporter neu starten."; }
  setup_env
fi
exec "$ENV/bin/python3" exporter.py "$@"
