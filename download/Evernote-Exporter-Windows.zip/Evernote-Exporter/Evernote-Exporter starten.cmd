@echo off
rem Evernote-Exporter starten (Windows). Aufruf: "Evernote-Exporter starten.cmd" [ORDNER]
rem Beim ersten Start wird evernote-backup einmalig eingerichtet (Internet noetig, ca. 1 Minute).
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0app"
set "ENV=%LOCALAPPDATA%\Evernote-Exporter\python"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto nopython
%PY% -c "import sys; sys.exit(sys.version_info < (3, 10))" || goto nopython
if exist "%ENV%\Scripts\evernote-backup.exe" goto run
echo Der Exporter wird einmalig eingerichtet ...
if exist "%ENV%" rmdir /s /q "%ENV%"
%PY% -m venv "%ENV%" || goto setupfail
"%ENV%\Scripts\python.exe" -m pip install -q "evernote-backup==1.14.0" || goto setupfail
:run
"%ENV%\Scripts\python.exe" exporter.py %*
exit /b %errorlevel%
:nopython
echo.
echo X Python 3.10 oder neuer fehlt.
echo   - Python kostenlos von python.org installieren (Haken bei "Add python.exe to PATH" setzen).
echo   - Dann den Exporter neu starten.
start "" https://www.python.org/downloads/windows/
pause
exit /b 1
:setupfail
if exist "%ENV%" rmdir /s /q "%ENV%"
echo.
echo X Die Einrichtung hat nicht geklappt.
echo   - Internet pruefen, dann den Exporter neu starten.
pause
exit /b 1
