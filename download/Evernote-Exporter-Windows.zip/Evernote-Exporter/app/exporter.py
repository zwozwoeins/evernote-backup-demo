#!/usr/bin/env python3
"""Evernote-Exporter: anmelden (offizielle Evernote-Seite), alle Notizbuecher holen, als .enex in einen Ordner schreiben.

Aufruf:  exporter.py [ORDNER]     ohne ORDNER wird gefragt (Enter = Vorschlag ~/Evernote-Export)
Keine Passwoerter oder Token im Protokoll. Eine Funktion = eine Aufgabe."""
import datetime
import os
import re
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from fehler import ExportFehler, classify, describe, resume_at  # noqa: E402

IS_WIN = sys.platform.startswith("win")
HOME = Path.home()
APP = Path(os.environ.get("EX_APP") or (Path(os.environ.get("LOCALAPPDATA", HOME)) / "Evernote-Exporter" if IS_WIN
                                        else HOME / ".local/share/evernote-exporter"))
DEFAULT_FOLDER = HOME / "Evernote-Export"
DB = APP / "evernote.db"
SYNC_OUT = APP / "sync.out"
LOGIN_OUT = APP / "anmeldung.out"
EB = os.environ.get("EX_EB") or str(Path(sys.executable).parent / ("evernote-backup.exe" if IS_WIN else "evernote-backup"))
PAUSE_EXTRA_S = int(os.environ.get("EX_PAUSE_EXTRA_S", 30))
MAX_ROUNDS = 48
TODO_RE = re.compile(r"(\d+) note\(s\) to download")
LINK_RE = re.compile(r"https://[^\s/]*(?:evernote|yinxiang)\.com/\S+")
INTERACTIVE = sys.stdin.isatty() and not os.environ.get("EX_NO_WAIT")


# ---------- Ausgabe ----------
def say(text=""):
    print(text, flush=True)


def ask(prompt):
    try:
        return input(prompt).strip()
    except EOFError:
        return ""


def wait_enter(text="Enter drücken zum Beenden."):
    if INTERACTIVE:
        ask(text)


def show_error(err):
    say()
    say("✗ " + err["text"])
    for i, step in enumerate(err["help"], 1):
        say("  %d. %s" % (i, step))


# ---------- Protokoll (nur Befehle und Ergebnis, nie Ausgaben mit Anmeldedaten) ----------
def ensure_app_dir():
    APP.mkdir(parents=True, exist_ok=True)
    os.chmod(APP, 0o700)


def log(msg):
    with open(APP / "exporter.log", "a", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")


def private_file(path):
    """Datei nur fuer den eigenen Benutzer (0600)."""
    return os.fdopen(os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w", encoding="utf-8")


def remove(path):
    try:
        Path(path).unlink()
    except OSError:
        pass


# ---------- Zielordner ----------
def folder_from_args(argv):
    args = [a for a in argv if not a.startswith("--")]
    return args[0] if args else ""


def ask_folder():
    say("Wohin sollen die Dateien gespeichert werden?")
    answer = ask("  Enter = %s\n  Ordner: " % DEFAULT_FOLDER)
    return answer or str(DEFAULT_FOLDER)


def clean_path(text):
    return Path(os.path.expandvars(text.strip().strip('"').strip("'"))).expanduser().resolve()


def check_folder(folder):
    """Ordner anlegen und pruefen, ob man hineinschreiben kann."""
    try:
        folder.mkdir(parents=True, exist_ok=True)
        probe = folder / ".schreibtest"
        probe.write_text("ok", "utf-8")
        probe.unlink()
    except OSError as e:
        raise ExportFehler("BAD_FOLDER", repr(e))


def choose_folder(argv):
    given = folder_from_args(argv)
    while True:
        folder = clean_path(given or ask_folder())
        try:
            check_folder(folder)
            return folder
        except ExportFehler as e:
            show_error(describe(e.code))
            if given or not INTERACTIVE:
                raise
        say()


# ---------- evernote-backup ----------
def eb_exists():
    if not Path(EB).exists():
        raise ExportFehler("SETUP", EB)


def auth_command():
    return "reauth" if DB.exists() else "init-db"


def login_import():
    """Windows: Anmeldung aus dem angemeldeten Evernote-Programm uebernehmen (ohne Tippen)."""
    if not IS_WIN:
        return False
    log("RUN %s import" % auth_command())
    p = subprocess.run([EB, auth_command(), "-d", str(DB), "--oauth-method", "import"], cwd=APP,
                       stdin=subprocess.DEVNULL, capture_output=True, text=True)
    log("EXIT %d (import)" % p.returncode)
    return p.returncode == 0


def login_start():
    log("RUN %s desktop" % auth_command())
    with private_file(LOGIN_OUT) as out:
        return subprocess.Popen([EB, auth_command(), "-d", str(DB), "--oauth-method", "desktop"], cwd=APP,
                                stdin=subprocess.PIPE, stdout=out, stderr=subprocess.STDOUT, text=True)


def read_text(path):
    try:
        return Path(path).read_text("utf-8", errors="replace")
    except OSError:
        return ""


def wait_for_link(proc, wait_s=20):
    end = time.time() + wait_s
    while time.time() < end and proc.poll() is None:
        m = LINK_RE.search(read_text(LOGIN_OUT))
        if m:
            return m.group(0)
        time.sleep(0.2)
    return ""


def explain_login(link):
    say()
    say("Anmelden – die Evernote-Seite öffnet sich im Browser.")
    say("  1. Dort anmelden: E-Mail und Passwort (oder Google/Apple). Fragt Evernote nach einem Code: Code eingeben.")
    say("  2. „Zugriff erlauben“ (Authorize) klicken.")
    say("  3. Mit der rechten Maustaste auf „Return to Evernote“ klicken → „Link kopieren“.")
    say("  4. Den Link hier einfügen (Rechtsklick oder Strg+Umschalt+V) und Enter drücken.")
    say("  Hat sich keine Seite geöffnet? Diese Adresse in den Browser kopieren:")
    say("  " + link)


def ask_link():
    """Fragt so lange, bis ein evernote://-Link kommt. Leere Eingabe = Abbruch."""
    while True:
        url = ask("Link: ")
        if not url or url.startswith("evernote://"):
            return url
        show_error(describe("BAD_LINK"))


def finish_login(proc, url):
    try:
        proc.communicate(url + "\n", timeout=120)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
    log("EXIT %s (Anmeldung)" % proc.returncode)
    return proc.returncode == 0


def stop(proc):
    if proc.poll() is None:
        proc.kill()
        proc.wait()


def login_error_code(text):
    code = classify(text)
    return code if code == "OFFLINE" else "LOGIN_FAILED"


def login_browser():
    proc = login_start()
    link = wait_for_link(proc)
    if not link:
        stop(proc)
        raise ExportFehler(login_error_code(read_text(LOGIN_OUT)), "kein Anmelde-Link")
    explain_login(link)
    url = ask_link()
    ok = bool(url) and finish_login(proc, url)
    stop(proc)
    remove(LOGIN_OUT)  # enthielt den Anmeldeablauf
    if not ok:
        raise ExportFehler("LOGIN_FAILED")


def login():
    if login_import():
        return say("✓ Anmeldung aus dem Evernote-Programm übernommen.")
    login_browser()
    say("✓ Angemeldet.")


# ---------- Holen mit Fortschritt ----------
def notes_in_db():
    try:
        con = sqlite3.connect("file:%s?mode=ro" % DB.as_posix(), uri=True, timeout=1)
        try:
            return con.execute("select count(*) from notes").fetchone()[0]
        finally:
            con.close()
    except sqlite3.Error:
        return 0


def sync_start():
    log("RUN sync")
    with private_file(SYNC_OUT) as out:
        return subprocess.Popen([EB, "sync", "-d", str(DB)], cwd=APP, stdin=subprocess.DEVNULL,
                                stdout=out, stderr=subprocess.STDOUT, text=True)


def todo_count():
    m = TODO_RE.findall(read_text(SYNC_OUT))
    return int(m[-1]) if m else 0


def progress_line(base):
    total = todo_count()
    if not total:
        return "  Verbindung zu Evernote … Notizbücher werden gezählt."
    done = min(total, max(0, notes_in_db() - base))
    return "  %d von %d Notizen geholt (%d %%)" % (done, total, done * 100 // total)


def show_progress(line):
    sys.stdout.write("\r" + line.ljust(60))
    sys.stdout.flush()


def sync_round():
    base = notes_in_db()
    proc = sync_start()
    while proc.poll() is None:
        show_progress(progress_line(base))
        time.sleep(1)
    show_progress(progress_line(base))
    say()
    log("EXIT %s (sync)" % proc.returncode)
    if proc.returncode != 0:
        out = read_text(SYNC_OUT)
        raise ExportFehler(classify(out), out[-600:])
    remove(SYNC_OUT)  # enthielt Konto-Name/E-Mail; nur fuer Fehler noetig


def countdown(until):
    while True:
        left = int((until - datetime.datetime.now()).total_seconds()) + PAUSE_EXTRA_S
        if left <= 0:
            return
        show_progress("  Pause: noch %d:%02d Minuten …" % (left // 60, left % 60))
        time.sleep(min(left, 5))


def pause(details):
    when = resume_at(details)
    say("Evernote macht eine Pause. Es geht um %s Uhr automatisch weiter – bitte Fenster offen lassen." % when.strftime("%H:%M"))
    countdown(when)
    say()
    say("Pause vorbei, es geht weiter …")


def sync_with_pauses():
    say("Notizen werden von Evernote geholt …")
    for _ in range(MAX_ROUNDS):
        try:
            return sync_round()
        except ExportFehler as e:
            if e.code != "RATE_LIMIT":
                raise
            pause(e.details)
    raise ExportFehler("SYNC_TIMEOUT")


# ---------- Dateien schreiben ----------
def export(folder):
    say("Dateien werden geschrieben …")
    log("RUN export")
    p = subprocess.run([EB, "export", "-d", str(DB), "--overwrite", str(folder)], cwd=APP,
                       stdin=subprocess.DEVNULL, capture_output=True, text=True)
    log("EXIT %d (export)" % p.returncode)
    if p.returncode != 0:
        raise ExportFehler(classify(p.stdout + p.stderr), (p.stdout + p.stderr)[-600:])


def count_files(folder):
    n = len(list(folder.rglob("*.enex")))
    if not n:
        raise ExportFehler("NO_FILES")
    return n


def open_folder(folder):
    if not INTERACTIVE:
        return
    try:
        if IS_WIN:
            os.startfile(str(folder))  # noqa: S606  (nur Windows)
        else:
            subprocess.Popen(["xdg-open", str(folder)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except (OSError, AttributeError):
        pass


def show_done(folder, files):
    say()
    say("✓ Fertig! %d Notizen in %d Dateien (.enex) gespeichert." % (notes_in_db(), files))
    say("  Ordner: %s" % folder)
    say("  Weiter: Im Notiz-Converter „Dateien wählen“ und alle Dateien aus diesem Ordner markieren.")
    say("  https://zwozwoeins.github.io/evernote-backup-demo/dashboard/")


# ---------- Ablauf ----------
def run_once(folder, need_login):
    eb_exists()
    if need_login or not DB.exists():
        login()
    sync_with_pauses()
    export(folder)
    return count_files(folder)


def handle_error(e, folder):
    """Fehler erklaeren; liefert (weiter?, neu anmelden?, Ordner)."""
    err = describe(e.code, e.details)
    show_error(err)
    log("FEHLER %s" % err["code"])
    if err["action"] == "quit" or not INTERACTIVE:
        wait_enter()
        return False, False, folder
    if err["action"] == "folder":
        return True, False, choose_folder([])
    if ask("\nEnter = nochmal versuchen, n + Enter = beenden: ").lower().startswith("n"):
        return False, False, folder
    return True, err["action"] == "login", folder


def main(argv):
    say("Evernote-Exporter – speichert alle Ihre Evernote-Notizbücher als Dateien.\n")
    ensure_app_dir()
    try:
        folder = choose_folder(argv)
    except ExportFehler:
        return wait_enter() or 2
    need_login = False
    while True:
        try:
            files = run_once(folder, need_login)
            break
        except ExportFehler as e:
            again, need_login, folder = handle_error(e, folder)
            if not again:
                return 1
        except Exception as e:  # noqa: BLE001  unerwartet -> trotzdem verstaendlich
            log("UNERWARTET %r" % e)
            again, need_login, folder = handle_error(ExportFehler("UNKNOWN", repr(e)), folder)
            if not again:
                return 1
        except KeyboardInterrupt:
            say("\nAbgebrochen. Beim nächsten Start geht es an derselben Stelle weiter.")
            return 130
    show_done(folder, files)
    open_folder(folder)
    wait_enter()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
