"""Fehler: ein einfacher Satz + konkrete Schritte. Technisches nur in "details" (nie Passwoerter/Token)."""
import datetime
import re


class ExportFehler(Exception):
    def __init__(self, code, details=""):
        super().__init__(code)
        self.code = code
        self.details = details


# code: (Text, was Enter dann tut, Hilfe-Schritte)
ERRORS = {
    "LOGIN_FAILED": ("Die Anmeldung hat nicht geklappt.", "login",
                     ["Auf der Evernote-Seite E-Mail und Passwort eingeben (oder Google/Apple wählen).",
                      "Fragt Evernote nach einem Code: den Code aus SMS oder App eingeben.",
                      "„Zugriff erlauben“ klicken, dann mit der rechten Maustaste auf „Return to Evernote“ → „Link kopieren“.",
                      "Den Link hier einfügen."]),
    "BAD_LINK": ("Das ist nicht der richtige Link.", "login",
                 ["Der Link muss mit evernote:// beginnen.",
                  "Rechte Maustaste auf „Return to Evernote“ → „Link kopieren“ → hier einfügen."]),
    "BAD_FOLDER": ("In diesen Ordner kann nicht gespeichert werden.", "folder",
                   ["Einen Ordner in Ihrem Benutzerordner wählen, z. B. Dokumente.",
                    "Oder einfach Enter drücken – dann wird der vorgeschlagene Ordner genommen."]),
    "LOGIN_EXPIRED": ("Die Anmeldung bei Evernote ist abgelaufen.", "login",
                      ["Enter drücken und neu anmelden. Alles bisher Geholte bleibt erhalten."]),
    "OFFLINE": ("Keine Verbindung zum Internet.", "sync", ["Internet/WLAN prüfen, dann Enter drücken."]),
    "SYNC_TIMEOUT": ("Das Holen dauert sehr lange.", "sync", ["Enter drücken. Es geht an derselben Stelle weiter."]),
    "NO_FILES": ("Evernote hat keine Notizen geliefert.", "sync",
                 ["Prüfen Sie auf evernote.com, ob Notizen da sind.", "Dann Enter drücken."]),
    "SETUP": ("evernote-backup fehlt.", "quit", ["Den Ordner „python“ des Exporters löschen und den Exporter neu starten."]),
    "UNKNOWN": ("Etwas ist schiefgelaufen.", "sync",
                ["Enter drücken für einen neuen Versuch.",
                 "Klappt es wieder nicht: Fenster schließen und den Exporter neu starten."]),
}



def describe(code, details=""):
    code = code if code in ERRORS else "UNKNOWN"
    text, action, help_steps = ERRORS[code]
    return {"code": code, "text": text, "action": action, "help": help_steps, "details": str(details)[-1500:]}


RATE_LIMIT_RE = re.compile(r"Rate limit reached\. Restart program at (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)(?: \(in ([\d:]+)\))?")
AUTH_EXPIRED_TEXTS = ("token expired or revoked", "refresh token is expired", "token expired",
                      "invalid authentication token", "re-authenticate")


def classify(text):
    t = (text or "").lower()
    if "rate limit reached" in t:
        return "RATE_LIMIT"
    if any(s in t for s in AUTH_EXPIRED_TEXTS):
        return "LOGIN_EXPIRED"
    if "connection" in t or "network" in t or "timed out" in t:
        return "OFFLINE"
    return "UNKNOWN"


def seconds_of(hms):
    parts = [int(p) for p in hms.split(":")]
    while len(parts) < 3:
        parts.insert(0, 0)
    return parts[0] * 3600 + parts[1] * 60 + parts[2]


def resume_at(text, now=None):
    """Wann Evernote wieder Daten liefert (Ortszeit). Ohne Angabe: in einer Stunde."""
    now = now or datetime.datetime.now()
    m = RATE_LIMIT_RE.search(text or "")
    if m and m.group(2):
        return now + datetime.timedelta(seconds=seconds_of(m.group(2)))
    if m:
        utc = datetime.datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").replace(tzinfo=datetime.timezone.utc)
        return utc.astimezone().replace(tzinfo=None)
    return now + datetime.timedelta(hours=1)
