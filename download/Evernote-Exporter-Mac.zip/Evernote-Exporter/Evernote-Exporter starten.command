#!/bin/bash
# Evernote-Exporter starten (Mac, Doppelklick).
# Beim allerersten Mal fragt der Mac: rechte Maustaste → „Öffnen“ → „Öffnen“.
exec "$(dirname "$0")/evernote-exporter.sh" "$@"
